<?php
/**
 * @package    bankaccount
 * @subpackage framework
 */
class RouterException extends RuntimeException
{
}
