<?php
/**
 * @package    bankaccount
 * @subpackage framework
 */
class ControllerException extends RuntimeException
{
}
