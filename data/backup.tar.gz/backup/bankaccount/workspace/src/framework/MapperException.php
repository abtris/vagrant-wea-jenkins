<?php
/**
 * @package    bankaccount
 * @subpackage framework
 */
class MapperException extends RuntimeException
{
}
