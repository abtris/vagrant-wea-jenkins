<?php
/**
 * @package    bankaccount
 * @subpackage model
 */
class BankAccountException extends RuntimeException
{
}
